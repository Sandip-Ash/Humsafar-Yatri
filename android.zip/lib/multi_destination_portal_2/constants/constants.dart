import 'package:flutter/material.dart';

String areaLocation = '';