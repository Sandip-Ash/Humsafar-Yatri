import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../widgets/app_large_text.dart';
import '../../widgets/app_text_welcome.dart';
import '../detail_page.dart';
import '../detailed_pages/detailed_page1.dart';
import '../detailed_pages/detailed_page2.dart';

class Home_Page extends StatefulWidget {
  const Home_Page({Key? key}) : super(key: key);

  @override
  State<Home_Page> createState() => _Home_PageState();
}

class _Home_PageState extends State<Home_Page> with TickerProviderStateMixin {
  var category = [
    "Best Places",
    "Most Visited",
    "Favourites",
    "Hotels",
    "Restaurants",
    "New Added",
  ];

//  var is like a dictionary//
  List city = [
    "darjeeling_1.jpeg",
    "kashmir.jpeg",
    "goa_2.jpeg",
  ];

  List names = [
    "Darjeeling",
    "Kashmir",
    "Goa"
  ];

// 2. //
  List city_1 = [
    "taj mahal.jpeg",
    "red fort.jpeg",
    "victoria memorial.jpeg",
  ];
  List names_1 = ["Taj mahal", "Red fort", "Victoria Memorial"];

  //3.//
  List city_2 = [
    "ooty.jpeg",
    "munnar.jpeg",
    "sundarban.jpeg",
  ];
  List names_2 = ["Ooty", "Munnar", "Sundarban"];

// explore more images ////

  var images = {
    "balloning.jpeg": "balloning",
    "hiking.jpeg": "hiking",
    "canoening.jpeg": "canoening",
    "kayaking.jpeg": "kayaking",
    "snorkling.jpeg": "snorkling"
  };

// navigation

  List<Widget> pages = const [
    DetailPage(),
    DetailedPage1(),
    DetailPage2(),
  ];

  List<bool> isBookmarked = [
    false,
    false,
    false
  ];

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersive);
  }

  @override
  Widget build(BuildContext context) {
    TabController _tabController = TabController(length: 3, vsync: this);
    return Scaffold(
        resizeToAvoidBottomInset: false,
        body: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {},
                      child: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            boxShadow: const [
                              BoxShadow(
                                  color: Colors.black,
                                  blurRadius: 0.6,
                                  offset: Offset(5, 4)
                              ),
                            ],
                            borderRadius: BorderRadius.circular(10)
                          ),
                          child: const Icon(
                            Icons.sort_rounded,
                            size: 28,
                          )
                      ),
                    ),

                    Row(
                      children: [
                        const Icon(
                          Icons.location_on,
                          color: Colors.red,
                        ),
                        Text(
                          'Durgapur,West Bengal',
                          style: GoogleFonts.aleo(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        )
                      ],
                    )
                  ]
                ),
              ),

              const SizedBox(
                height: 20,
              ),

              Align(
                alignment: Alignment.centerLeft,
                child: Container(
                  margin: const EdgeInsets.only(left: 20),
                  child: AppLargeText(text: 'Discover'),
                ),
              ),

              const SizedBox(
                height: 20,
              ),

              // tab bar//

              Align(
                alignment: Alignment.centerLeft,
                child: TabBar(
                  labelPadding: const EdgeInsets.only(left: 20, right: 30),
                  controller: _tabController,
                  labelColor: Colors.black,
                  unselectedLabelColor: Colors.grey,
                  isScrollable: true,
                  indicatorSize: TabBarIndicatorSize.label,
                  tabs: const [
                    Tab(
                      text: 'places',
                    ),
                    Tab(text: 'Historical'),
                    Tab(text: 'emotions'),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.only(left: 20),
                width: double.maxFinite,
                height: 300,
                child: TabBarView(
                  controller: _tabController,
                  children: [

                    //1.//
                    ListView.builder(
                      itemCount: 3,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, int index) {
                        return GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => pages[index]    // Replace NewScreen() with the name of your new screen widget
                              ),
                            );
                          },
                          child: Container(
                            margin: const EdgeInsets.only(right: 10, top: 10),
                            width: 200,
                            height: 300,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                color: Colors.white,
                                image: DecorationImage(
                                  image: AssetImage(
                                    'assets/images/${city[index]}',
                                  ),
                                  fit: BoxFit.cover,
                                )
                            ),

                            child: Column(
                              children: [
                                Container(
                                  padding: const EdgeInsets.only(top: 10, right: 10),
                                  alignment: Alignment.topRight,
                                  child: IconButton(
                                    // Use IconButton instead of Icon to enable onPressed
                                    onPressed: () {},
                                    icon: const Icon(
                                      Icons.bookmark_border,
                                      color: Colors.white,
                                      size: 30,
                                    ),
                                  ),
                                ),

                                const Spacer(),

                                Container(
                                  padding: const EdgeInsets.only(bottom: 20, left: 20),
                                  alignment: Alignment.bottomLeft,
                                  child: Text(
                                    names[index],
                                    style: GoogleFonts.amita(
                                        color: Colors.yellow,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 18),
                                  ),
                                )
                              ],
                            ),
                          ),
                        );
                      },
                    ),

                    //2.//

                    ListView.builder(
                      itemCount: 3,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, int index) {
                        return GestureDetector(
                          onTap: () {
                            print('image clicked!');
                          },

                          child: Container(
                            margin: const EdgeInsets.only(right: 10, top: 10),
                            width: 200,
                            height: 300,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.white,
                              image: DecorationImage(
                                image: AssetImage(
                                  'assets/images/${city_1[index]}',
                                ),
                                fit: BoxFit.cover
                              )
                            ),

                            child: Column(
                              children: [
                                Container(
                                  padding: const EdgeInsets.only(top: 10, right: 10),
                                  alignment: Alignment.topRight,
                                  child: const Icon(
                                    Icons.bookmark_border_outlined,
                                    color: Colors.white,
                                    size: 30,
                                  ),
                                ),

                                const Spacer(),

                                Container(
                                  padding: const EdgeInsets.only(bottom: 20, left: 20),
                                  alignment: Alignment.bottomLeft,
                                  child: Text(
                                    names_1[index],
                                    style: GoogleFonts.amita(
                                        color: Colors.yellow,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 18),
                                  ),
                                )
                              ],
                            ),
                          ),
                        );
                      },
                    ),

                    // 3.
                    ListView.builder(
                      itemCount: 3,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (BuildContext context, int index) {
                        return GestureDetector(
                          onTap: () {
                            print('image clicked!');
                          },

                          child: Container(
                            margin: const EdgeInsets.only(right: 10, top: 10),
                            width: 200,
                            height: 300,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.white,
                              image: DecorationImage(
                                image: AssetImage(
                                  'assets/images/${city_2[index]}',
                                ),
                                fit: BoxFit.cover
                              )
                            ),

                            child: Column(
                              children: [
                                Container(
                                  padding: const EdgeInsets.only(top: 10, right: 10),
                                  alignment: Alignment.topRight,
                                  child: const Icon(
                                    Icons.bookmark_border_outlined,
                                    color: Colors.white,
                                    size: 30,
                                  ),
                                ),

                                const Spacer(),

                                Container(
                                  padding:
                                      const EdgeInsets.only(bottom: 20, left: 20),
                                  alignment: Alignment.bottomLeft,
                                  child: Text(
                                    names_2[index],
                                    style: GoogleFonts.amita(
                                        color: Colors.yellow,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 18),
                                  ),
                                )
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),

              const SizedBox(
                height: 20,
              ),

              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: Row(
                    children: [
                      for (int i = 0; i < 6; i++)
                        Container(
                          margin: const EdgeInsets.symmetric(horizontal: 10),
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(8),
                            boxShadow: const [
                              BoxShadow(
                                color: Colors.black54,
                                blurRadius: 4,
                              )
                            ]
                          ),

                          child: Text(
                            category[i],
                            style: GoogleFonts.anekMalayalam(
                              fontSize: 15,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        )
                    ],
                  ),
                ),
              ),

              const SizedBox(
                height: 20,
              ),

              Container(
                margin: const EdgeInsets.only(left: 20, right: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    AppLargeText(
                      text: 'Explore more',
                      size: 22,
                    ),
                    AppText(
                      text: 'See all',
                      color: Colors.black,
                    )
                  ],
                ),
              ),

              const SizedBox(
                height: 30,
              ),

              Container(
                height: 100,
                width: double.maxFinite,
                margin: const EdgeInsets.only(left: 20),
                child: ListView.builder(
                    itemCount: 5,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (_, index) {
                      return Container(
                        margin: const EdgeInsets.only(right: 30),
                        child: Column(
                          children: [
                            Container(
                              //margin: EdgeInsets.only(right: 50),
                              width: 70,
                              height: 70,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                color: Colors.white,
                                image: DecorationImage(
                                    image: AssetImage(
                                      'assets/images/${images.keys.elementAt(index)}',
                                    ),
                                    fit: BoxFit.cover
                                )
                              ),
                            ),

                            const SizedBox(
                              height: 5,
                            ),

                            AppText(
                              text: images.values.elementAt(index),
                              color: Colors.black,
                            )
                          ],
                        ),
                      );
                    }),
              )
            ],
          ),
        )
    );
  }
}
