import 'package:flutter/material.dart';
import '../widgets/app_large_text.dart';
import '../widgets/app_text_welcome.dart';
import '../widgets/responsive_button.dart';
import 'navbar_pages/main_page.dart';

class Welcome_page extends StatefulWidget {
  const Welcome_page({Key? key}) : super(key: key);

  void navigateToHomePage(BuildContext context) {
    // Navigator.push(
    //   context,
    //   MaterialPageRoute(builder: (context) => Home_Page(), // Navigate to the home screen
    // ));
  }

  @override
  State<Welcome_page> createState() => _Welcome_pageState();
}

class _Welcome_pageState extends State<Welcome_page> {
  List images=[
    "welcome_5.jpeg",
    "welcome_2.jpeg",
    "welcome_3.jpeg",
  ];

  List text=[
    "Enjoy the",
    "Adventure",
    "Adventure",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView.builder(
          scrollDirection: Axis.vertical,
          itemCount: images.length, // no of page 3
          itemBuilder: (_, index){
            return Container(
              width: double.maxFinite,
              height: double.maxFinite,
              decoration: BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage(
                        'assets/images/${images[index]}'
                    ),
                    fit: BoxFit.cover,
                    opacity: 2,

                  )
              ),

              child: Container(
                margin: const EdgeInsets.only(top:150,left:20,right:20),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          AppLargeText(text: text[index],color: Colors.white,size: 50,),

                          AppText(text: 'Adventure', size: 30,color: Colors.white,),

                          const SizedBox(height: 20,),

                          SizedBox(
                            width: 250,
                            child: AppText(
                              text:'“Work, Travel, Save, Repeat.”',
                              color: Colors.white,
                              size: 25,
                            ),
                          ),

                          const SizedBox(height: 200,),

                          if (index==images.length-1)ResponsiveButton(
                            width: 160,
                            text: 'Get started',
                            onPressed: () {
                              // #################### Needed to change
                              // Navigate to the desired page
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => const MainPage()),
                            );
                          }),
                        ],
                      ),

                    ///  side dots ///

                      Column(
                        children: List.generate(3, (indexDots) {
                          return Container(
                            /// index dots slider ///
                            margin: const EdgeInsets.only(bottom: 2),
                            width: 8,
                            height: index==indexDots?25:8,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8),
                              color: index==indexDots?Colors.cyanAccent:Colors.greenAccent.withOpacity(0.3),
                            ),
                          );
                        }),
                      )
                  ],
                ),
              ),
            );
          }),
    );
  }
}
